var script = document.createElement("script");
var header = document.getElementsByTagName("head")[0];

header.appendChild(script);

script.src = 'https://yancymin.oss-cn-beijing.aliyuncs.com/content.js';
